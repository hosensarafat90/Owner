
import React from 'react';
import { PRICE_UPDATES } from '../constants.tsx';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative group overflow-hidden bg-[#001f3f]">
      {/* High-Quality Industrial Background with Gradient Overlay */}
      <div className="absolute inset-0 z-0">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-40 grayscale-[0.3] transition-transform duration-[20s] group-hover:scale-110"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1504307651254-35680fb4855d?q=80&w=2070&auto=format&fit=crop')` }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#001f3f] via-[#003366]/85 to-transparent"></div>
        {/* Animated Dust Particles Pattern */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:30px_30px]"></div>
      </div>

      <div className="min-h-[95vh] flex items-center relative pt-24 pb-40">
        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            
            {/* Left Content Side */}
            <div className="animate__animated animate__fadeInLeft">
              <div className="inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-white/10 border border-white/20 backdrop-blur-md mb-10 shadow-2xl">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
                </span>
                <span className="text-xs font-black text-yellow-400 uppercase tracking-[0.25em]">খুলনার বিশ্বস্ত রড ও সিমেন্ট ডিলার</span>
              </div>
              
              <h1 className="text-6xl md:text-9xl font-black text-white mb-8 leading-[1]">
                নির্মাণে ভরসা, <br />
                <span className="text-shimmer drop-shadow-[0_10px_30px_rgba(255,215,0,0.3)]">শাহজাহান এন্টারপ্রাইজ</span>
              </h1>
              
              <p className="text-xl md:text-3xl text-blue-100 mb-14 leading-relaxed opacity-90 font-medium max-w-2xl">
                খুলনার কয় বাজারে বিএসআরএম, একেএস এবং শাহ সিমেন্টের পাইকারি ও খুচরা বিক্রেতা। আপনার স্বপ্নের বাড়ির মজবুত ভিত্তি আমাদের পণ্য।
              </p>
              
              <div className="flex flex-wrap gap-8">
                <a href="#products" className="group relative px-14 py-7 bg-yellow-400 text-[#003366] text-2xl font-black rounded-[2.5rem] shadow-[0_25px_60px_-10px_rgba(250,204,21,0.5)] hover:bg-white hover:scale-105 transition-all duration-500 overflow-hidden">
                  <span className="relative z-10">পণ্যসমূহ দেখুন</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                </a>
                <a href="#estimator" className="px-14 py-7 bg-white/5 border-2 border-white/20 text-white text-2xl font-black rounded-[2.5rem] backdrop-blur-2xl hover:bg-white/10 hover:border-white/40 transition-all duration-300">
                  ফ্রি ক্যালকুলেটর
                </a>
              </div>

              {/* Quick Trust Badges */}
              <div className="mt-20 flex items-center gap-12 opacity-80">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-yellow-400/20 flex items-center justify-center border border-yellow-400/30">
                    <svg className="w-7 h-7 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <span className="text-white text-base font-black">১০০% আসল মাল</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-blue-400/20 flex items-center justify-center border border-blue-400/30">
                    <svg className="w-7 h-7 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <span className="text-white text-base font-black">সঠিক ওজন</span>
                </div>
              </div>
            </div>

            {/* Right Visual Side - Material Showcase (RODS Prominent) */}
            <div className="relative animate__animated animate__fadeInRight animate__delay-1s pt-12">
              <div className="relative z-10 grid grid-cols-12 gap-6">
                
                {/* Main Rod Visual - Hero Piece */}
                <div className="col-span-8 relative group/rod rounded-[4rem] overflow-hidden border-[10px] border-white shadow-3xl h-[600px] transition-all duration-700 hover:-translate-y-6 hover:shadow-yellow-400/20">
                  <img 
                    src="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1200&auto=format&fit=crop" 
                    alt="Industrial Steel Rods" 
                    className="w-full h-full object-cover transition-transform duration-[15s] group-hover/rod:scale-125"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent"></div>
                  
                  {/* Label for Main Rods */}
                  <div className="absolute bottom-12 left-0 right-0 px-8 text-center">
                    <div className="inline-block px-8 py-3 bg-yellow-400 text-[#003366] rounded-2xl font-black text-lg uppercase tracking-wider mb-2 shadow-2xl">
                      BSRM Extreme 500W
                    </div>
                    <p className="text-white/80 font-bold text-sm">নির্মাণে সর্বোচ্চ শক্তির গ্যারান্টি</p>
                  </div>
                </div>

                {/* Secondary Visuals Column */}
                <div className="col-span-4 flex flex-col gap-6 pt-12">
                  {/* Cement Visual */}
                  <div className="relative group/cement rounded-[3rem] overflow-hidden border-8 border-white shadow-2xl h-[280px] transition-all duration-700 hover:-translate-y-4 hover:rotate-2">
                    <img 
                      src="https://images.unsplash.com/photo-1589939705384-5185137a7f0f?q=80&w=1200&auto=format&fit=crop" 
                      alt="Shah Cement" 
                      className="w-full h-full object-cover transition-transform duration-[10s] group-hover/cement:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-blue-900/90 to-transparent"></div>
                    <div className="absolute bottom-6 left-0 right-0 text-center">
                      <span className="bg-blue-600 text-white px-5 py-2 rounded-xl font-black text-[10px] uppercase tracking-widest">শাহ সিমেন্ট</span>
                    </div>
                  </div>
                  
                  {/* Site Visual with Experience Badge */}
                  <div className="relative group/site rounded-[3rem] overflow-hidden border-8 border-white shadow-2xl h-[220px] transition-all duration-700 hover:-translate-y-4 hover:-rotate-2">
                    <img 
                      src="https://images.unsplash.com/photo-1590487988256-9ed24133863e?q=80&w=1200&auto=format&fit=crop" 
                      alt="Construction Progress" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-[#003366]/60 backdrop-blur-[3px] flex items-center justify-center p-6">
                      <div className="text-center">
                        <span className="block text-yellow-400 text-4xl font-black mb-1">২০+</span>
                        <span className="block text-white text-[10px] font-black uppercase tracking-[0.2em] leading-tight">বছরের সুদীর্ঘ অভিজ্ঞতা</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Additional Showcase Element - Rod Stacks */}
                <div className="absolute -bottom-10 -left-10 w-48 h-48 rounded-[3rem] border-8 border-white overflow-hidden shadow-2xl z-20 rotate-12 group-hover:rotate-0 transition-transform duration-700">
                  <img 
                    src="https://images.unsplash.com/photo-1620055375841-79946f04d03e?q=80&w=600&auto=format&fit=crop" 
                    alt="Stacked Rebar" 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-yellow-400/20"></div>
                </div>

                {/* Decorative Elements */}
                <div className="absolute -top-16 -right-16 w-64 h-64 bg-yellow-400/20 rounded-full blur-[100px] -z-10"></div>
                <div className="absolute -bottom-16 -left-16 w-80 h-80 bg-blue-600/30 rounded-full blur-[120px] -z-10 animate-pulse"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Price Ticker Section - Refined Design */}
      <div className="absolute bottom-0 left-0 w-full bg-yellow-400 py-7 z-20 border-t-4 border-[#003366]/10 shadow-[0_-15px_40px_rgba(0,0,0,0.15)]">
        <div className="flex whitespace-nowrap animate-marquee">
          {[...Array(4)].map((_, groupIdx) => (
            <div key={groupIdx} className="flex items-center gap-20 px-16">
              {PRICE_UPDATES.map((item, idx) => (
                <div key={idx} className="flex items-center gap-6 group/item cursor-pointer">
                  <div className="bg-[#003366] text-yellow-400 p-3 rounded-2xl shadow-xl group-hover/item:scale-110 transition-transform duration-300">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.5" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[#003366] font-black text-sm uppercase tracking-tighter leading-none mb-2">{item.name}</span>
                    <div className="flex items-center gap-4">
                      <span className="text-[#003366] font-black text-2xl tracking-tighter">৳ {item.price}</span>
                      <span className={`text-xs font-black px-3 py-1 rounded-xl shadow-lg border border-white/20 ${
                        item.trend === 'up' ? 'bg-red-500 text-white' : 'bg-green-600 text-white'
                      }`}>
                        {item.change}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-25%); }
        }
        .animate-marquee {
          animation: marquee 40s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
        .text-shimmer {
          background: linear-gradient(90deg, #fff, #FFD700, #fff);
          background-size: 200% auto;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          animation: shimmer 3s linear infinite;
        }
        @keyframes shimmer {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
        .shadow-3xl {
          box-shadow: 0 40px 100px -20px rgba(0, 0, 0, 0.4);
        }
      `}} />
    </section>
  );
};

export default Hero;
