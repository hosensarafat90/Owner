
import React, { useState, useEffect } from 'react';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`sticky top-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-[#003366]/95 backdrop-blur-xl py-2 shadow-2xl' : 'bg-[#003366] py-4'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <a href="#home" className="flex flex-col group">
              <span className="text-2xl md:text-3xl font-black text-yellow-400 tracking-tighter leading-none group-hover:scale-105 transition-transform origin-left">
                SHAJAHAN <span className="text-white">ENTERPRISE</span>
              </span>
              <span className="text-[10px] md:text-xs font-bold text-blue-100 uppercase tracking-[0.2em] mt-1.5 opacity-90 border-t border-white/10 pt-1">
                আপনার বিশ্বস্ত পার্টনার
              </span>
            </a>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-8">
              <a href="#home" className="text-white hover:text-yellow-400 font-bold text-sm uppercase tracking-widest transition-all hover:-translate-y-0.5 active:translate-y-0">মূল পাতা</a>
              <a href="#about" className="text-white hover:text-yellow-400 font-bold text-sm uppercase tracking-widest transition-all hover:-translate-y-0.5 active:translate-y-0">আমাদের সম্পর্কে</a>
              <a href="#products" className="text-white hover:text-yellow-400 font-bold text-sm uppercase tracking-widest transition-all hover:-translate-y-0.5 active:translate-y-0">পণ্যসমূহ</a>
              <a href="#estimator" className="text-white hover:text-yellow-400 font-bold text-sm uppercase tracking-widest transition-all hover:-translate-y-0.5 active:translate-y-0">ক্যালকুলেটর</a>
              <a href="#contact" className="bg-yellow-400 text-[#003366] px-8 py-3.5 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-white transition-all shadow-xl hover:shadow-yellow-400/20 active:scale-95">যোগাযোগ</a>
            </div>
          </div>
          <div className="md:hidden flex items-center">
            <button 
              onClick={() => setIsOpen(!isOpen)} 
              className="text-yellow-400 p-2 focus:outline-none transition-transform active:scale-90"
              aria-label="Toggle Menu"
            >
              <svg className="h-9 w-9" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 6h16M4 12h16m-7 6h7" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu Overlay */}
      <div className={`md:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsOpen(false)}></div>
      
      {/* Mobile Menu Panel */}
      <div className={`md:hidden fixed top-0 right-0 h-full w-[80%] max-w-sm bg-[#003366] z-50 transform transition-transform duration-500 ease-in-out shadow-[-20px_0_50px_rgba(0,0,0,0.5)] ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="p-6 flex justify-end">
            <button onClick={() => setIsOpen(false)} className="text-yellow-400 p-2">
              <svg className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <div className="px-8 flex flex-col space-y-8 mt-4">
            <a href="#home" onClick={() => setIsOpen(false)} className="text-3xl font-black text-white hover:text-yellow-400 transition-colors">মূল পাতা</a>
            <a href="#about" onClick={() => setIsOpen(false)} className="text-3xl font-black text-white hover:text-yellow-400 transition-colors">আমাদের সম্পর্কে</a>
            <a href="#products" onClick={() => setIsOpen(false)} className="text-3xl font-black text-white hover:text-yellow-400 transition-colors">পণ্যসমূহ</a>
            <a href="#estimator" onClick={() => setIsOpen(false)} className="text-3xl font-black text-white hover:text-yellow-400 transition-colors">ক্যালকুলেটর</a>
            <div className="pt-10">
              <a href="#contact" onClick={() => setIsOpen(false)} className="block w-full py-6 bg-yellow-400 text-[#003366] text-center rounded-[2rem] font-black text-2xl shadow-2xl shadow-yellow-400/20 active:scale-95 transition-all">যোগাযোগ করুন</a>
            </div>
          </div>
          
          <div className="mt-auto p-10 border-t border-white/10">
            <p className="text-blue-100/60 text-sm font-bold uppercase tracking-widest text-center">আপনার বিশ্বস্ত পার্টনার</p>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Header;
