
import React, { useState, useEffect } from 'react';

const Estimator: React.FC = () => {
  const [area, setArea] = useState<number>(1200);
  const [results, setResults] = useState({ rod: 0, cement: 0 });

  useEffect(() => {
    const rodVal = (area * 0.004).toFixed(2);
    const cementVal = Math.ceil(area * 0.45);
    setResults({ rod: parseFloat(rodVal), cement: cementVal });
  }, [area]);

  return (
    <section id="estimator" className="py-32 industrial-gradient relative overflow-hidden">
      {/* Structural background lines */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="80" height="80" patternUnits="userSpaceOnUse">
              <path d="M 80 0 L 0 0 0 80" fill="none" stroke="white" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <div className="animate__animated animate__fadeInLeft">
            <h2 className="text-4xl md:text-6xl font-black text-white mb-8 leading-tight">
              নির্মাণ সামগ্রীর <br />
              <span className="text-yellow-400">স্মার্ট ক্যালকুলেটর</span>
            </h2>
            <p className="text-xl text-blue-100/70 mb-12 leading-relaxed">
              আপনার স্বপ্নের বাড়ির আয়তন দিয়ে প্রয়োজনীয় রড ও সিমেন্টের আনুমানিক হিসাব পান মুহূর্তেই। এটি একটি ইঞ্জিনিয়ারিং এস্টিমেশন টুল।
            </p>
            
            <div className="bg-white/10 backdrop-blur-2xl p-10 rounded-[3.5rem] border border-white/20 shadow-3xl">
              <div className="flex justify-between items-end mb-8">
                <label className="text-sm font-black text-blue-200 uppercase tracking-widest">বাড়ির আয়তন (Sqft)</label>
                <span className="text-4xl font-black text-yellow-400">{area}</span>
              </div>
              
              <input 
                type="range" 
                min="500" 
                max="10000" 
                step="50"
                value={area}
                onChange={(e) => setArea(Number(e.target.value))}
                className="w-full h-4 bg-white/20 rounded-full appearance-none cursor-pointer accent-yellow-400 mb-6"
              />
              
              <div className="grid grid-cols-2 gap-4">
                <button onClick={() => setArea(1000)} className="py-3 bg-white/5 rounded-xl text-xs font-black hover:bg-white/20 transition-all">১০০০ SQFT</button>
                <button onClick={() => setArea(2500)} className="py-3 bg-white/5 rounded-xl text-xs font-black hover:bg-white/20 transition-all">২৫০০ SQFT</button>
              </div>
            </div>
          </div>

          <div className="grid gap-8 animate__animated animate__fadeInRight">
            {/* Rod Dashboard Card */}
            <div className="relative group overflow-hidden bg-white rounded-[3.5rem] p-12 transition-all duration-500 hover:-rotate-2">
              <div className="absolute top-0 right-0 w-40 h-40 bg-blue-50 rounded-bl-[10rem] opacity-50 group-hover:scale-110 transition-transform"></div>
              <div className="relative z-10">
                <div className="w-16 h-16 bg-[#003366] text-yellow-400 rounded-2xl flex items-center justify-center mb-8 shadow-xl">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                  </svg>
                </div>
                <h3 className="text-slate-400 font-black text-sm uppercase tracking-widest mb-4">প্রয়োজনীয় রড (আনুমানিক)</h3>
                <div className="flex items-baseline gap-4">
                  <span className="text-7xl font-black text-[#003366]">{results.rod}</span>
                  <span className="text-2xl font-bold text-slate-500">মেট্রিক টন</span>
                </div>
              </div>
            </div>

            {/* Cement Dashboard Card */}
            <div className="relative group overflow-hidden bg-yellow-400 rounded-[3.5rem] p-12 transition-all duration-500 hover:rotate-2">
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/20 rounded-bl-[10rem] opacity-50 group-hover:scale-110 transition-transform"></div>
              <div className="relative z-10">
                <div className="w-16 h-16 bg-white text-[#003366] rounded-2xl flex items-center justify-center mb-8 shadow-xl">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                  </svg>
                </div>
                <h3 className="text-blue-900/60 font-black text-sm uppercase tracking-widest mb-4">প্রয়োজনীয় সিমেন্ট (আনুমানিক)</h3>
                <div className="flex items-baseline gap-4">
                  <span className="text-7xl font-black text-blue-900">{results.cement}</span>
                  <span className="text-2xl font-bold text-blue-900/60">ব্যাগ</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Estimator;
