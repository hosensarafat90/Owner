
import React from 'react';
import { PARTNERS } from '../constants.tsx';

const Partners: React.FC = () => {
  // We duplicate the list to create a seamless infinite scroll effect
  const marqueePartners = [...PARTNERS, ...PARTNERS, ...PARTNERS];

  return (
    <section id="partners" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-blue-50 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 opacity-60"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-yellow-50 rounded-full blur-3xl translate-x-1/2 translate-y-1/2 opacity-60"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#003366]/5 border border-[#003366]/10 mb-4">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
            </span>
            <span className="text-xs font-black text-[#003366] uppercase tracking-[0.2em]">অফিসিয়াল ডিস্ট্রিবিউশন</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-black text-[#003366] mb-6">
            আমাদের বিশ্বস্ত <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#003366] to-blue-600">পার্টনারস</span>
          </h2>
          <p className="text-lg text-gray-500 max-w-2xl mx-auto leading-relaxed">
            আমরা দেশের শীর্ষস্থানীয় ব্র্যান্ডগুলোর অনুমোদিত ডিলার। সরাসরি ফ্যাক্টরি থেকে পণ্য সরবরাহ করি বলে আমরা অরিজিনাল মালের গ্যারান্টি দিতে পারি।
          </p>
        </div>

        {/* Desktop Grid (Hidden on Mobile for Scroll) */}
        <div className="hidden lg:grid grid-cols-6 gap-6 mb-12">
          {PARTNERS.map((partner) => (
            <div 
              key={partner.id} 
              className="group relative h-32 bg-gray-50 rounded-3xl border border-gray-100 flex items-center justify-center p-6 transition-all duration-500 hover:bg-white hover:shadow-2xl hover:shadow-blue-900/10 hover:-translate-y-2 overflow-hidden cursor-default"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-transparent to-[#003366]/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              
              {/* Animated Partner Name/Logo Container */}
              <div className="relative z-10 transition-all duration-500 transform group-hover:scale-110">
                <span className="text-xl font-black text-gray-400 group-hover:text-[#003366] transition-colors duration-300">
                  {partner.name}
                </span>
              </div>

              <div className="absolute bottom-0 left-0 w-full h-1 bg-yellow-400 scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500"></div>
            </div>
          ))}
        </div>

        {/* Mobile & Tablet Infinite Marquee */}
        <div className="lg:hidden relative group">
          {/* Fade Overlays */}
          <div className="absolute inset-y-0 left-0 w-20 bg-gradient-to-r from-white to-transparent z-20 pointer-events-none"></div>
          <div className="absolute inset-y-0 right-0 w-20 bg-gradient-to-l from-white to-transparent z-20 pointer-events-none"></div>

          <div className="flex overflow-hidden space-x-6 py-4">
            <div className="flex animate-marquee space-x-6 whitespace-nowrap">
              {marqueePartners.map((partner, idx) => (
                <div 
                  key={`${partner.id}-${idx}`}
                  className="group inline-flex items-center justify-center px-10 py-6 bg-gray-50 rounded-2xl border border-gray-100 min-w-[180px] shadow-sm active:scale-95 transition-all duration-300 hover:bg-white hover:shadow-md hover:-translate-y-1"
                >
                  <span className="text-lg font-black text-[#003366] transition-transform duration-300 group-hover:scale-110">
                    {partner.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Partnership Trust Badge */}
        <div className="mt-12 flex flex-wrap justify-center gap-8 md:gap-16 items-center border-t border-gray-100 pt-12">
          <div className="flex items-center gap-4 group cursor-default">
            <div className="w-12 h-12 rounded-2xl bg-yellow-400 text-[#003366] flex items-center justify-center shadow-lg shadow-yellow-400/20 group-hover:rotate-12 group-hover:scale-110 transition-transform duration-300">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div className="text-left">
              <p className="text-sm font-black text-[#003366] uppercase tracking-tighter">১০০% আসল পণ্য</p>
              <p className="text-xs text-gray-500">সরাসরি কোম্পানি ডেলিভারি</p>
            </div>
          </div>

          <div className="flex items-center gap-4 group cursor-default">
            <div className="w-12 h-12 rounded-2xl bg-[#003366] text-white flex items-center justify-center shadow-lg shadow-blue-900/20 group-hover:-rotate-12 group-hover:scale-110 transition-transform duration-300">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
              </svg>
            </div>
            <div className="text-left">
              <p className="text-sm font-black text-[#003366] uppercase tracking-tighter">নির্ভুল ওজন</p>
              <p className="text-xs text-gray-500">ডিজিটাল স্কেলে ওজন করা</p>
            </div>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 30s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
      `}} />
    </section>
  );
};

export default Partners;
