
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-32 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          {/* Visual Side */}
          <div className="relative group">
            {/* Main Background Box */}
            <div className="absolute -inset-6 bg-[#003366]/5 rounded-[4rem] rotate-2"></div>
            
            {/* Primary Heritage Image - Showing Premium Rod Stock */}
            <div className="relative overflow-hidden rounded-[3.5rem] shadow-2xl border-8 border-white z-10 h-[600px]">
              <img 
                src="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1200&auto=format&fit=crop" 
                alt="Construction Materials Stock" 
                className="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#001f3f]/80 via-transparent to-transparent"></div>
            </div>

            {/* "Established 2000" Floating Visual - Showing Cement and Scale */}
            <div className="absolute -bottom-10 -right-10 z-20 w-56 h-56 md:w-72 md:h-72 rounded-[3.5rem] overflow-hidden border-8 border-white shadow-3xl animate__animated animate__fadeInRight">
              <img 
                src="https://images.unsplash.com/photo-1589939705384-5185137a7f0f?q=80&w=600&auto=format&fit=crop" 
                alt="Premium Cement Supply" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-[#003366]/40 flex flex-col items-center justify-center text-center p-6 backdrop-blur-[2px]">
                 <span className="text-yellow-400 text-5xl font-black mb-2">২০০০</span>
                 <span className="text-white text-xs font-black uppercase tracking-[0.3em]">সালে প্রতিষ্ঠিত</span>
              </div>
            </div>

            {/* Experience Badge */}
            <div className="absolute top-10 -left-10 z-30 bg-white p-8 rounded-[2.5rem] shadow-2xl border border-blue-50 flex items-center gap-6 animate__animated animate__fadeInLeft">
               <div className="w-16 h-16 bg-yellow-400 text-[#003366] rounded-2xl flex items-center justify-center shadow-lg">
                 <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-10V4m0 10V4m-4 18h8" />
                 </svg>
               </div>
               <div>
                 <h4 className="text-3xl font-black text-[#003366]">২৪ বছর</h4>
                 <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">অবিচল আস্থার প্রতীক</p>
               </div>
            </div>
          </div>

          {/* Content Side */}
          <div className="space-y-12 animate__animated animate__fadeInUp">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-50 text-blue-600 mb-6 border border-blue-100">
                <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
                <span className="text-xs font-black uppercase tracking-widest">আমাদের সম্পর্কে জানুন</span>
              </div>
              <h2 className="text-4xl md:text-7xl font-black text-[#003366] leading-tight mb-8">
                শাহজাহান এন্টারপ্রাইজ: <br />
                <span className="text-blue-600 underline decoration-yellow-400 decoration-8 underline-offset-8">২ দশকের বিশ্বস্ততা</span>
              </h2>
            </div>

            <div className="text-xl text-gray-600 leading-relaxed space-y-6">
              <p className="font-medium text-slate-800">
                ২০০০ সালে খুলনার কয় বাজারে যাত্রা শুরু করে শাহজাহান এন্টারপ্রাইজ। দীর্ঘ ২৪ বছর ধরে আমরা সততা ও স্বচ্ছতার সাথে রড ও সিমেন্ট সরবরাহ করে আসছি। 
              </p>
              <p>
                বিএসআরএম, একেএস এবং শাহ সিমেন্টের মতো শীর্ষস্থানীয় ব্রান্ডের অনুমোদিত ডিলার হিসেবে আমরা আপনার নির্মাণের স্থায়িত্ব নিশ্চিত করতে সর্বদা প্রতিশ্রুতিবদ্ধ। প্রতিটি ড্রাম সিমেন্ট বা এক টন রড—সবকিছুতেই আমরা দিই সঠিক ওজন ও আসল মানের গ্যারান্টি।
              </p>
            </div>

            <div className="grid grid-cols-2 gap-8 pt-8 border-t border-gray-100">
              <div className="flex flex-col gap-2">
                <span className="text-4xl font-black text-[#003366]">১০০০+</span>
                <span className="text-sm font-bold text-gray-400 uppercase tracking-widest">সন্তুষ্ট গ্রাহক</span>
              </div>
              <div className="flex flex-col gap-2">
                <span className="text-4xl font-black text-[#003366]">৫০+</span>
                <span className="text-sm font-bold text-gray-400 uppercase tracking-widest">বড় প্রজেক্ট</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
