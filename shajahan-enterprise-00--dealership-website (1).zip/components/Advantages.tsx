
import React from 'react';
import CountUp from 'react-countup';

const ADVANTAGES = [
  {
    title: 'আসল পণ্যের নিশ্চয়তা',
    count: 20,
    suffix: '+ বছর',
    description: 'বিএসআরএম ও শাহ সিমেন্টের অনুমোদিত ডিলার হিসেবে ২০ বছরেরও বেশি সময়ের অভিজ্ঞতা।',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    )
  },
  {
    title: 'সঠিক ওজন ও মাপ',
    count: 10000,
    suffix: '+ টন',
    description: 'নির্ভুল ডিজিটাল ওয়েট মেশিনে মেপে এ পর্যন্ত ১০ হাজার টনেরও বেশি পণ্য সরবরাহ করা হয়েছে।',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
      </svg>
    )
  },
  {
    title: 'দ্রুত ডেলিভারি',
    count: 2500,
    suffix: '+ সাইট',
    description: 'নিজস্ব পরিবহনে ২৫০০টিরও বেশি নির্মাণ সাইটে সময়মতো পণ্য পৌঁছে দেওয়া হয়েছে।',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    )
  },
  {
    title: 'সন্তুষ্ট গ্রাহক',
    count: 1500,
    suffix: '+ জন',
    description: 'খুলনা ও পার্শ্ববর্তী অঞ্চলের ১৫০০ জনেরও বেশি নিয়মিত সন্তুষ্ট গ্রাহকের ভালোবাসা।',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    )
  }
];

const Advantages: React.FC = () => {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-50 border border-yellow-100 mb-4">
            <span className="w-2 h-2 rounded-full bg-yellow-600 animate-ping"></span>
            <span className="text-xs font-black text-yellow-700 uppercase tracking-widest">কেন আমাদের সেরা বলা হয়</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-black text-[#003366] mb-6">নির্মাণে আমাদের শ্রেষ্ঠত্ব</h2>
          <div className="w-24 h-1.5 bg-yellow-400 mx-auto rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {ADVANTAGES.map((item, index) => (
            <div 
              key={index} 
              className="group p-8 rounded-[2.5rem] border border-gray-100 bg-gray-50/50 hover:bg-white hover:shadow-[0_20px_60px_-15px_rgba(0,51,102,0.1)] transition-all duration-500 flex flex-col items-center text-center relative overflow-hidden"
            >
              {/* Background Glow */}
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-yellow-400/5 rounded-full blur-3xl group-hover:bg-yellow-400/10 transition-colors duration-500"></div>

              {/* Animated Icon Container */}
              <div 
                className="relative w-20 h-20 bg-[#003366] text-yellow-400 rounded-3xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-500 shadow-xl shadow-blue-900/20 animate-subtle-float"
                style={{ animationDelay: `${index * 300}ms` }}
              >
                <div className="absolute inset-0 bg-white/5 rounded-3xl group-hover:bg-white/10 transition-colors"></div>
                <div className="relative z-10 transform group-hover:rotate-12 transition-transform duration-300">
                  {item.icon}
                </div>
              </div>
              
              <div className="text-4xl font-black text-[#003366] mb-3 flex items-baseline gap-1">
                <CountUp 
                  end={item.count} 
                  duration={3} 
                  enableScrollSpy={true} 
                  scrollSpyOnce={true}
                />
                <span className="text-lg font-bold text-yellow-500 uppercase tracking-tight">{item.suffix}</span>
              </div>

              <h3 className="text-xl font-black text-[#003366] mb-4 group-hover:text-blue-800 transition-colors">{item.title}</h3>
              <p className="text-gray-500 leading-relaxed text-sm font-medium">
                {item.description}
              </p>

              {/* Bottom Accent */}
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-1 bg-yellow-400 group-hover:w-1/2 transition-all duration-500 rounded-t-full"></div>
            </div>
          ))}
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes subtle-float {
          0%, 100% { transform: translateY(0) scale(1); }
          50% { transform: translateY(-8px) scale(1.02); }
        }
        .animate-subtle-float {
          animation: subtle-float 4s ease-in-out infinite;
        }
        
        /* Staggered entry animation for the cards themselves if desired */
        .advantage-card {
          opacity: 0;
          transform: translateY(20px);
          transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
        }
        .advantage-card.is-visible {
          opacity: 1;
          transform: translateY(0);
        }
      `}} />
    </section>
  );
};

export default Advantages;
