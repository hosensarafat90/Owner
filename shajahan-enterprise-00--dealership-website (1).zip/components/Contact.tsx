
import React, { useState } from 'react';
import { CONTACT_INFO } from '../constants.tsx';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form Submitted:', formData);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <section id="contact" className="py-16 md:py-24 bg-[#003366] text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-8">
        <div className="text-center mb-12 md:text-left md:mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 text-yellow-400">যোগাযোগ করুন</h2>
          <p className="text-lg md:text-xl text-blue-100 max-w-2xl">
            যেকোনো প্রকার অর্ডারের জন্য বা পণ্যের তথ্য জানতে আজই আমাদের সাথে যোগাযোগ করুন।
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 md:gap-16 items-start">
          {/* Inquiry Form */}
          <div className="bg-white/5 backdrop-blur-md p-6 sm:p-10 rounded-3xl border border-white/10 shadow-2xl order-2 lg:order-1">
            <h3 className="text-xl md:text-2xl font-bold mb-8 text-white flex items-center gap-3">
              <div className="p-2 bg-yellow-400/10 rounded-lg">
                <svg className="w-6 h-6 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              তদন্ত ফরম
            </h3>
            
            {submitted ? (
              <div className="bg-green-500/20 border border-green-500 text-green-200 p-4 rounded-xl text-center mb-6 text-sm font-medium">
                আপনার বার্তা সফলভাবে পাঠানো হয়েছে!
              </div>
            ) : null}

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-bold text-blue-200 uppercase tracking-wider mb-2">নাম</label>
                  <input
                    type="text"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-4 text-white placeholder-blue-300/50 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition-all"
                    placeholder="আপনার নাম"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-blue-200 uppercase tracking-wider mb-2">ইমেইল</label>
                  <input
                    type="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-4 text-white placeholder-blue-300/50 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition-all"
                    placeholder="example@mail.com"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-blue-200 uppercase tracking-wider mb-2">ফোন নম্বর</label>
                <input
                  type="tel"
                  name="phone"
                  required
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-4 text-white placeholder-blue-300/50 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition-all"
                  placeholder="০১৭xxxxxxxx"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-blue-200 uppercase tracking-wider mb-2">বার্তা</label>
                <textarea
                  name="message"
                  required
                  rows={4}
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-4 text-white placeholder-blue-300/50 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition-all resize-none"
                  placeholder="আপনার বার্তাটি এখানে লিখুন..."
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-yellow-400 text-blue-900 font-bold py-5 rounded-xl hover:bg-yellow-300 active:scale-[0.98] transition-all shadow-xl flex items-center justify-center gap-3 text-lg"
              >
                বার্তা পাঠান
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </button>
            </form>
          </div>

          {/* Contact Details & Map */}
          <div className="space-y-8 order-1 lg:order-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white/5 p-6 rounded-2xl border border-white/10 flex items-start gap-4">
                <div className="bg-yellow-400/10 p-3 rounded-xl text-yellow-400">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-yellow-400 uppercase tracking-widest mb-1">ঠিকানা</h4>
                  <p className="text-blue-100 font-medium">{CONTACT_INFO.address}</p>
                </div>
              </div>

              <div className="bg-white/5 p-6 rounded-2xl border border-white/10 flex items-start gap-4">
                <div className="bg-yellow-400/10 p-3 rounded-xl text-yellow-400">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-yellow-400 uppercase tracking-widest mb-1">মালিক</h4>
                  <p className="text-blue-100 font-medium">{CONTACT_INFO.owner}</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-2 rounded-3xl shadow-2xl overflow-hidden h-[250px] md:h-[350px] border-4 border-white/10">
              <iframe
                title="Shajahan Enterprise Location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d117565.41991822839!2d89.431268383848!3d22.845420379435422!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39ff8f9807572d47%3A0x8673f4e2f3d61b36!2sKhulna!5e0!3m2!1sen!2sbd!4v1690000000000!5m2!1sen!2sbd"
                className="w-full h-full border-0 rounded-2xl grayscale contrast-125"
                allowFullScreen={true}
                loading="lazy"
              ></iframe>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href={`tel:${CONTACT_INFO.phone}`}
                className="flex-1 flex items-center justify-center gap-3 bg-yellow-400 text-blue-900 px-6 py-5 rounded-xl font-bold text-lg hover:bg-yellow-300 active:scale-95 transition-all shadow-xl"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 005.47 5.47l.772-1.547a1 1 0 011.06-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
                </svg>
                সরাসরি কল করুন
              </a>
              <a
                href={`https://wa.me/${CONTACT_INFO.whatsapp.replace('+', '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 flex items-center justify-center gap-3 bg-green-500 text-white px-6 py-5 rounded-xl font-bold text-lg hover:bg-green-600 active:scale-95 transition-all shadow-xl"
              >
                <svg className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.246 2.248 3.484 5.232 3.484 8.412-.003 6.557-5.338 11.892-11.893 11.892-1.997-.001-3.951-.5-5.688-1.448l-6.309 1.656zm6.29-4.143c1.589.943 3.133 1.415 4.75 1.416 5.482.002 9.944-4.461 9.947-9.945.001-2.657-1.034-5.155-2.913-7.034-1.88-1.879-4.375-2.912-7.033-2.913-5.483 0-9.944 4.461-9.947 9.945 0 1.764.466 3.489 1.346 5.004l-1.012 3.705 3.859-1.013zm11.215-7.149c-.214-.107-1.27-.627-1.466-.697-.196-.071-.34-.107-.482.107-.143.214-.553.697-.678.839-.125.142-.249.159-.463.053-.214-.107-.905-.333-1.725-1.064-.638-.569-1.069-1.272-1.194-1.485-.125-.213-.013-.328.093-.434.097-.095.214-.249.321-.373.107-.125.142-.214.214-.356.071-.143.036-.267-.018-.373-.054-.107-.482-1.161-.661-1.591-.174-.419-.366-.362-.503-.369-.13-.007-.279-.009-.428-.009s-.392.056-.597.279c-.205.223-.784.767-.784 1.868s.802 2.162.913 2.311c.111.149 1.577 2.408 3.821 3.376.534.23 1.054.436 1.413.551.536.171 1.023.146 1.408.089.43-.064 1.27-.519 1.448-.1.178-.519.178-.962.125-1.033-.053-.072-.196-.115-.41-.222z" />
                </svg>
                হোয়াটসঅ্যাপ
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;