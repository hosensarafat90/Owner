
import React, { useState, useMemo } from 'react';
import { PRODUCTS } from '../constants.tsx';
import { Product } from '../types';
import ProductCard from './ProductCard';

const Products: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'All' | 'Rod' | 'Cement'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [comparedProducts, setComparedProducts] = useState<Product[]>([]);
  const [showComparison, setShowComparison] = useState(false);

  const categories = ['All', 'Rod', 'Cement'] as const;

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(product => {
      const matchesCategory = activeCategory === 'All' || product.category === activeCategory;
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           product.brand.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery]);

  const toggleComparison = (product: Product) => {
    setComparedProducts(prev => {
      const isAlreadyIn = prev.some(p => p.id === product.id);
      if (isAlreadyIn) {
        return prev.filter(p => p.id !== product.id);
      }
      if (prev.length >= 3) {
        alert("একসাথে সর্বোচ্চ ৩টি পণ্য তুলনা করা সম্ভব।");
        return prev;
      }
      return [...prev, product];
    });
  };

  const removeProduct = (id: string) => {
    setComparedProducts(prev => prev.filter(p => p.id !== id));
  };

  const clearAllComparison = () => {
    setComparedProducts([]);
  };

  return (
    <section id="products" className="py-24 bg-gray-50 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Section */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-[#003366] mb-4">আমাদের পণ্যসমূহ</h2>
          <div className="w-24 h-1 bg-yellow-400 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            দেশের সেরা ব্রান্ডের আসল রড ও সিমেন্ট—যা আপনার নির্মাণকে দেবে আজীবন শক্তি ও নিরাপত্তা।
          </p>
        </div>

        {/* Controls: Search and Filter */}
        <div className="mb-12 flex flex-col md:flex-row gap-6 items-center justify-between bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
          <div className="flex bg-gray-100 p-1.5 rounded-2xl w-full md:w-auto" role="tablist" aria-label="Product categories">
            {categories.map((cat) => (
              <button
                key={cat}
                role="tab"
                aria-selected={activeCategory === cat}
                onClick={() => setActiveCategory(cat)}
                className={`flex-1 md:flex-none px-8 py-3 rounded-xl text-sm font-bold transition-all outline-none focus:ring-2 focus:ring-[#003366] ${
                  activeCategory === cat
                    ? 'bg-[#003366] text-white shadow-lg scale-105'
                    : 'text-gray-500 hover:text-[#003366] hover:bg-white'
                }`}
              >
                {cat === 'All' ? 'সব পণ্য' : cat === 'Rod' ? 'রড' : 'সিমেন্ট'}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-96 group">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <svg className="h-5 w-5 text-gray-400 group-focus-within:text-yellow-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input
              type="text"
              placeholder="ব্র্যান্ড বা পণ্যের নাম খুঁজুন..."
              aria-label="পণ্য খুঁজুন"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="block w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-[#003366] transition-all"
            />
          </div>
        </div>
        
        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-10">
          {filteredProducts.map(product => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onCompareToggle={toggleComparison}
              isCompared={comparedProducts.some(p => p.id === product.id)}
            />
          ))}
        </div>

        {/* Empty State */}
        {filteredProducts.length === 0 && (
          <div className="py-20 text-center" role="status">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-10 h-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold text-gray-400">কোনো পণ্য পাওয়া যায়নি</h3>
            <button onClick={() => {setSearchQuery(''); setActiveCategory('All');}} className="mt-4 text-[#003366] font-bold underline outline-none focus:ring-2 focus:ring-[#003366] rounded px-2">ফিল্টার মুছুন</button>
          </div>
        )}

        {/* Technical Note */}
        <div className="mt-16 bg-[#003366]/5 rounded-3xl p-8 border border-[#003366]/10 flex flex-col md:flex-row items-center gap-6">
          <div className="p-4 bg-yellow-400 text-[#003366] rounded-2xl shadow-xl shrink-0">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <h4 className="text-lg font-bold text-[#003366] mb-1">গুরুত্বপূর্ণ তথ্য</h4>
            <p className="text-gray-600 text-sm md:text-base">
              বাজারের অস্থিতিশীলতার কারণে পণ্যের দাম প্রতিদিন পরিবর্তিত হতে পারে। সর্বশেষ দাম জানতে সরাসরি যোগাযোগ করুন।
            </p>
          </div>
        </div>
      </div>

      {/* Comparison Sticky Bar */}
      {comparedProducts.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-[60] bg-[#003366]/95 backdrop-blur-2xl border-t border-white/10 p-4 md:p-6 shadow-[0_-20px_50px_rgba(0,0,0,0.5)] animate-fadeIn">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-6 w-full md:w-auto justify-between md:justify-start">
              <div className="flex flex-col">
                <span className="text-yellow-400 font-black text-xs uppercase tracking-widest mb-1">প্রোডাক্ট তুলনা</span>
                <span className="text-white text-sm font-bold">{comparedProducts.length} টি পণ্য সিলেক্ট করা হয়েছে</span>
              </div>
              <button 
                onClick={clearAllComparison}
                aria-label="সব পণ্য তুলনা থেকে সরান"
                className="text-red-400 hover:text-red-300 text-xs font-black uppercase tracking-tighter transition-colors flex items-center gap-1 outline-none focus:ring-2 focus:ring-red-400 rounded p-1"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                সব মুছুন
              </button>
            </div>
            
            <div className="flex items-center gap-4 overflow-x-auto no-scrollbar py-2 w-full md:w-auto justify-center">
              {comparedProducts.map(p => (
                <div key={p.id} className="relative group shrink-0">
                  <div className="w-14 h-14 md:w-20 md:h-20 rounded-2xl overflow-hidden border-2 border-white/20 shadow-lg group-hover:border-yellow-400 transition-colors">
                    <img src={p.image} className="w-full h-full object-cover" alt={p.name} />
                  </div>
                  <button 
                    onClick={() => removeProduct(p.id)}
                    aria-label={`${p.name} তুলনা থেকে সরান`}
                    className="absolute -top-2 -right-2 bg-red-500 text-white p-1.5 rounded-full shadow-xl hover:scale-110 transition-all border-2 border-[#003366] z-10 focus:ring-2 focus:ring-white outline-none"
                  >
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              ))}
              {comparedProducts.length < 3 && (
                <div className="w-14 h-14 md:w-20 md:h-20 rounded-2xl border-2 border-dashed border-white/20 flex flex-col items-center justify-center gap-1 text-white/30 shrink-0">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
                  </svg>
                  <span className="text-[8px] font-bold uppercase tracking-widest">বাকি {3 - comparedProducts.length}</span>
                </div>
              )}
            </div>

            <button 
              onClick={() => setShowComparison(true)}
              disabled={comparedProducts.length < 2}
              aria-label="তুলনা শুরু করুন"
              className={`w-full md:w-auto px-8 md:px-12 py-4 rounded-2xl font-black text-sm md:text-lg transition-all flex items-center justify-center gap-3 shadow-2xl outline-none focus:ring-4 focus:ring-yellow-200 ${
                comparedProducts.length >= 2 
                ? 'bg-yellow-400 text-[#003366] hover:bg-yellow-300 scale-105 active:scale-95' 
                : 'bg-white/10 text-white/40 cursor-not-allowed opacity-50'
              }`}
            >
              <span>তুলনা করুন</span>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* Detailed Comparison Modal */}
      {showComparison && (
        <div 
          className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-3xl flex items-center justify-center p-4 md:p-8 animate-fadeInFast"
          role="dialog"
          aria-modal="true"
          aria-label="পণ্যের বিস্তারিত তুলনা মডাল"
        >
          <div className="bg-white w-full max-w-6xl max-h-[90vh] rounded-[3rem] overflow-hidden shadow-2xl flex flex-col relative animate-scaleIn">
            {/* Modal Header */}
            <div className="p-6 md:p-10 border-b border-gray-100 flex items-center justify-between shrink-0 bg-[#003366] text-white">
              <div>
                <h3 className="text-2xl md:text-4xl font-black mb-1">পণ্যের বিস্তারিত তুলনা</h3>
                <p className="text-blue-200 text-sm md:text-base font-medium">আপনার পছন্দের পণ্যগুলোর পাশাপাশি কারিগরি তুলনা করুন</p>
              </div>
              <button 
                onClick={() => setShowComparison(false)}
                aria-label="বন্ধ করুন"
                className="p-4 bg-white/10 hover:bg-red-500 rounded-full transition-all text-white group outline-none focus:ring-2 focus:ring-white"
              >
                <svg className="w-6 h-6 group-hover:rotate-90 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Modal Content - Comparison Table */}
            <div className="flex-grow overflow-auto p-4 md:p-10 custom-scrollbar">
              <div className="min-w-[700px]">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b-2 border-gray-100">
                      <th className="py-8 px-4 w-1/4 text-xs font-black text-gray-400 uppercase tracking-[0.2em]">বৈশিষ্ট্যসমূহ</th>
                      {comparedProducts.map(p => (
                        <th key={p.id} className="py-8 px-4 w-1/4">
                          <div className="flex flex-col gap-6">
                            <div className="aspect-[16/10] rounded-[2rem] overflow-hidden border-4 border-gray-50 shadow-lg relative group/thumb">
                              <img src={p.image} className="w-full h-full object-cover group-hover/thumb:scale-110 transition-transform duration-700" alt={p.name} />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                              <span className="absolute bottom-4 left-4 text-white font-black text-xs uppercase tracking-widest">{p.brand}</span>
                            </div>
                            <h4 className="text-xl md:text-2xl font-black text-[#003366] leading-tight">{p.name}</h4>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    <tr className="group hover:bg-gray-50 transition-colors">
                      <td className="py-8 px-4 font-black text-gray-400 text-xs uppercase tracking-widest">ব্র্যান্ড</td>
                      {comparedProducts.map(p => (
                        <td key={p.id} className="py-8 px-4">
                          <span className="px-5 py-2.5 bg-blue-100 text-[#003366] rounded-xl font-black text-sm shadow-sm">{p.brand}</span>
                        </td>
                      ))}
                    </tr>
                    <tr className="group hover:bg-gray-50 transition-colors">
                      <td className="py-8 px-4 font-black text-gray-400 text-xs uppercase tracking-widest">ক্যাটাগরি</td>
                      {comparedProducts.map(p => (
                        <td key={p.id} className="py-8 px-4">
                          <span className="px-5 py-2.5 bg-yellow-400/10 text-yellow-700 border border-yellow-200 rounded-xl font-black text-sm">
                            {p.category === 'Rod' ? 'রড' : 'সিমেন্ট'}
                          </span>
                        </td>
                      ))}
                    </tr>
                    <tr className="group hover:bg-gray-50 transition-colors">
                      <td className="py-8 px-4 font-black text-gray-400 text-xs uppercase tracking-widest">বিস্তারিত বর্ণনা</td>
                      {comparedProducts.map(p => (
                        <td key={p.id} className="py-8 px-4">
                          <p className="text-gray-600 text-sm md:text-base leading-relaxed italic font-medium">"{p.description}"</p>
                        </td>
                      ))}
                    </tr>
                    <tr className="group hover:bg-gray-50 transition-colors">
                      <td className="py-8 px-4 font-black text-gray-400 text-xs uppercase tracking-widest">গুণমান মানদণ্ড</td>
                      {comparedProducts.map(p => (
                        <td key={p.id} className="py-8 px-4">
                          <div className="flex items-center gap-3 text-green-600">
                            <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                              </svg>
                            </div>
                            <span className="font-black text-sm uppercase tracking-tighter">BUET সার্টিফাইড / ১০০% আসল</span>
                          </div>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-8 md:p-12 border-t border-gray-100 bg-gray-50 flex flex-col md:flex-row items-center justify-between gap-8 shrink-0">
              <div className="flex items-center gap-4 text-gray-500">
                <svg className="w-10 h-10 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-sm font-medium leading-tight">
                  পণ্যের বর্তমান স্টক এবং সর্বশেষ পাইকারি রেট জানতে <br className="hidden md:block"/> সরাসরি আমাদের সাথে কথা বলুন।
                </p>
              </div>
              <div className="flex gap-4 w-full md:w-auto">
                <button 
                  onClick={() => setShowComparison(false)}
                  className="flex-1 md:flex-none px-10 py-5 bg-white border-2 border-gray-200 text-gray-600 font-black rounded-2xl hover:bg-gray-50 transition-all text-sm uppercase tracking-widest outline-none focus:ring-2 focus:ring-gray-300"
                >
                  ফিরে যান
                </button>
                <a 
                  href="#contact" 
                  onClick={() => setShowComparison(false)}
                  className="flex-1 md:flex-none px-12 py-5 bg-[#003366] text-white font-black rounded-2xl hover:bg-blue-800 transition-all shadow-xl shadow-blue-900/20 text-center text-sm uppercase tracking-widest outline-none focus:ring-4 focus:ring-blue-200"
                >
                  অর্ডার করুন
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(40px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.9) translateY(20px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        .animate-scaleIn {
          animation: scaleIn 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f8fafc;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e2e8f0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #cbd5e1;
        }
      `}} />
    </section>
  );
};

export default Products;
