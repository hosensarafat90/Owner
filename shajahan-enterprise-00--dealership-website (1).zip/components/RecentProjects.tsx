
import React, { useState, useEffect } from 'react';
import { PROJECTS } from '../constants.tsx';

const RecentProjects: React.FC = () => {
  const [visibleCount, setVisibleCount] = useState(3);
  const [isAnimating, setIsAnimating] = useState(false);
  
  const handleShowMore = () => {
    setIsAnimating(true);
    setTimeout(() => {
      setVisibleCount(prev => Math.min(prev + 5, PROJECTS.length));
      setIsAnimating(false);
    }, 300);
  };

  const visibleProjects = PROJECTS.slice(0, visibleCount);
  const hasMore = visibleCount < PROJECTS.length;

  return (
    <section id="projects" className="py-32 bg-slate-50 relative overflow-hidden">
      {/* Decorative background text */}
      <div className="absolute top-20 right-0 text-[15rem] font-black text-slate-100 select-none pointer-events-none -mr-40 leading-none">
        WORKS
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
          <div className="max-w-2xl animate__animated animate__fadeInUp">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#003366] text-white mb-6">
              <span className="text-xs font-black uppercase tracking-[0.2em]">গৌরবময় প্রজেক্টসমূহ</span>
            </div>
            <h2 className="text-4xl md:text-6xl font-black text-[#003366] leading-tight">
              আমাদের সরবরাহিত <br />
              <span className="text-blue-600 underline decoration-yellow-400 decoration-8 underline-offset-8">সেরা স্থাপনাসমূহ</span>
            </h2>
          </div>
          <div className="text-slate-500 font-medium max-w-sm">
            আমরা শুধু মাল সাপ্লাই করি না, আমরা প্রতিটি স্থাপনার স্থায়িত্ব নিশ্চিত করি। খুলনার বড় প্রজেক্টগুলো আমাদের ওপর ভরসা রাখে।
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {visibleProjects.map((project, index) => (
            <div 
              key={project.id} 
              className={`group relative h-[500px] rounded-[3rem] overflow-hidden shadow-2xl hover:shadow-blue-900/20 transition-all duration-500 hover:-translate-y-3 animate__animated animate__fadeInUp`}
              style={{ animationDelay: `${(index % 3) * 150}ms` }}
            >
              {/* Premium Image Layer */}
              <img 
                src={project.image} 
                alt={project.title} 
                className="w-full h-full object-cover transition-transform duration-[2s] group-hover:scale-110"
              />
              
              {/* Dynamic Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#001f3f] via-[#003366]/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>
              
              {/* Information */}
              <div className="absolute inset-0 p-10 flex flex-col justify-end text-white">
                <div className="mb-4 transform translate-y-6 group-hover:translate-y-0 transition-all duration-500">
                  <span className={`inline-block px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest mb-4 border ${
                    project.status === 'সম্পন্ন' ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-yellow-400/20 text-yellow-400 border-yellow-400/30'
                  }`}>
                    {project.status}
                  </span>
                  <h3 className="text-3xl font-black mb-3 leading-tight group-hover:text-yellow-400 transition-colors">
                    {project.title}
                  </h3>
                  <div className="flex items-center gap-2 text-white/60 text-sm">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    </svg>
                    {project.location}
                  </div>
                </div>
                
                {/* Expandable Details */}
                <div className="max-h-0 group-hover:max-h-24 overflow-hidden transition-all duration-700 delay-100 opacity-0 group-hover:opacity-100">
                   <div className="pt-6 border-t border-white/10 flex flex-wrap gap-2">
                     {project.materials.map((m, i) => (
                       <span key={i} className="text-[10px] font-bold px-3 py-1 bg-white/10 rounded-lg backdrop-blur-md">
                         {m}
                       </span>
                     ))}
                   </div>
                </div>
              </div>

              {/* Icon Overlay */}
              <div className="absolute top-8 right-8 w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 rotate-12 group-hover:rotate-0">
                <svg className="w-7 h-7 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          ))}
        </div>

        {/* Load More Controller */}
        <div className="mt-20 flex flex-col items-center">
          {hasMore ? (
            <button 
              onClick={handleShowMore}
              disabled={isAnimating}
              className={`group relative inline-flex items-center gap-4 px-14 py-6 bg-[#003366] text-white rounded-[2rem] font-black text-lg shadow-2xl transition-all duration-300 hover:shadow-blue-900/40 active:scale-95 ${isAnimating ? 'opacity-50' : ''}`}
            >
              <span>{isAnimating ? 'লোড হচ্ছে...' : 'আরো প্রজেক্ট দেখুন'}</span>
              <div className="relative w-8 h-8 flex items-center justify-center bg-yellow-400 text-blue-900 rounded-full transition-transform duration-500 group-hover:rotate-180">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 4v16m8-8H4" />
                </svg>
              </div>
            </button>
          ) : (
            <div className="px-10 py-4 bg-slate-200 text-slate-500 rounded-full font-bold text-sm">
              সবগুলো উল্লেখযোগ্য প্রজেক্ট দেখানো হয়েছে
            </div>
          )}
          
          <div className="mt-8 flex items-center gap-4 text-slate-400 text-sm font-bold">
            <span className="w-8 h-[2px] bg-slate-200"></span>
            সর্বমোট {PROJECTS.length}টি প্রজেক্টের মধ্যে {visibleCount}টি দেখানো হচ্ছে
            <span className="w-8 h-[2px] bg-slate-200"></span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RecentProjects;
