
import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { Product, Review } from '../types';

interface ProductCardProps {
  product: Product;
  onCompareToggle: (product: Product) => void;
  isCompared: boolean;
}

const AUTO_SLIDE_INTERVAL = 6000;

const ProductCard: React.FC<ProductCardProps> = ({ product, onCompareToggle, isCompared }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [reviews, setReviews] = useState<Review[]>(product.reviews || []);
  const [newReview, setNewReview] = useState({ userName: '', rating: 5, comment: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  
  // Lightbox & Pan Zoom State
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [lightboxIdx, setLightboxIdx] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [panPos, setPanPos] = useState({ x: 50, y: 50 });
  const containerRef = useRef<HTMLDivElement>(null);

  const averageRating = useMemo(() => {
    if (reviews.length === 0) return 0;
    const total = reviews.reduce((sum, r) => sum + r.rating, 0);
    return (total / reviews.length).toFixed(1);
  }, [reviews]);

  const nextImage = useCallback((e?: React.MouseEvent | React.KeyboardEvent | KeyboardEvent) => {
    if (e && 'preventDefault' in e) e.preventDefault();
    setCurrentIdx((prev) => (prev + 1) % product.productImages.length);
  }, [product.productImages.length]);

  const prevImage = useCallback((e?: React.MouseEvent | React.KeyboardEvent | KeyboardEvent) => {
    if (e && 'preventDefault' in e) e.preventDefault();
    setCurrentIdx((prev) => (prev - 1 + product.productImages.length) % product.productImages.length);
  }, [product.productImages.length]);

  const nextLightboxImage = useCallback(() => {
    setLightboxIdx((prev) => (prev + 1) % product.productImages.length);
    setIsZoomed(false);
  }, [product.productImages.length]);

  const prevLightboxImage = useCallback(() => {
    setLightboxIdx((prev) => (prev - 1 + product.productImages.length) % product.productImages.length);
    setIsZoomed(false);
  }, [product.productImages.length]);

  // Auto-slide effect
  useEffect(() => {
    if (isHovered || isLightboxOpen || product.productImages.length <= 1) return;
    const interval = setInterval(nextImage, AUTO_SLIDE_INTERVAL);
    return () => clearInterval(interval);
  }, [isHovered, isLightboxOpen, nextImage, product.productImages.length]);

  // Keyboard navigation for Lightbox
  useEffect(() => {
    if (!isLightboxOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') nextLightboxImage();
      if (e.key === 'ArrowLeft') prevLightboxImage();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isLightboxOpen, nextLightboxImage, prevLightboxImage]);

  const openLightbox = (index: number) => {
    setLightboxIdx(index);
    setIsLightboxOpen(true);
    setIsZoomed(false);
    setPanPos({ x: 50, y: 50 });
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = useCallback(() => {
    setIsLightboxOpen(false);
    setIsZoomed(false);
    document.body.style.overflow = 'unset';
  }, []);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isZoomed || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setPanPos({ x, y });
  };

  const toggleZoom = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isZoomed) {
      const rect = e.currentTarget.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      setPanPos({ x, y });
    }
    setIsZoomed(!isZoomed);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.userName || !newReview.comment) return;
    setIsSubmitting(true);
    setTimeout(() => {
      const review: Review = {
        id: Math.random().toString(36).substr(2, 9),
        userName: newReview.userName,
        rating: newReview.rating,
        comment: newReview.comment,
        date: new Date().toISOString().split('T')[0]
      };
      setReviews([review, ...reviews]);
      setNewReview({ userName: '', rating: 5, comment: '' });
      setIsSubmitting(false);
      setShowReviewForm(false);
    }, 800);
  };

  const renderStars = (rating: number, interactive = false) => {
    return (
      <div className="flex gap-1" role="img" aria-label={`Rating: ${rating} out of 5 stars`}>
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            disabled={!interactive}
            onClick={() => interactive && setNewReview({ ...newReview, rating: star })}
            aria-label={`Rate ${star} stars`}
            className={`${interactive ? 'hover:scale-125 focus:scale-125' : ''} transition-transform duration-200 focus:outline-none`}
          >
            <svg 
              className={`w-4 h-4 md:w-5 md:h-5 ${star <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.921-.755 1.688-1.54 1.118l-3.976-2.888a1 1 0 00-1.175 0l-3.976 2.888c-.784.57-1.838-.197-1.539-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
            </svg>
          </button>
        ))}
      </div>
    );
  };

  return (
    <div 
      className="bg-white rounded-[2.5rem] shadow-sm overflow-hidden hover:shadow-2xl transition-all duration-500 border border-gray-100 group flex flex-col h-full min-h-[750px] md:min-h-[850px]"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Enhanced Image Gallery Container */}
      <div 
        className="aspect-[16/10] sm:h-80 overflow-hidden relative bg-gray-900 group/gallery shrink-0 cursor-zoom-in focus-within:ring-4 focus-within:ring-yellow-400 focus-within:ring-inset"
        onClick={() => openLightbox(currentIdx)}
        role="region"
        aria-label="Product image gallery"
      >
        {/* Transition Layers */}
        <div className="absolute inset-0 z-0">
          {product.productImages.map((img, index) => (
            <div 
              key={index} 
              className={`absolute inset-0 transition-all duration-[1200ms] ease-in-out ${
                currentIdx === index ? 'opacity-100 scale-100' : 'opacity-0 scale-110 pointer-events-none'
              }`}
            >
              <img 
                src={img} 
                alt={`${product.name} দৃশ্য ${index + 1}`} 
                className="w-full h-full object-cover brightness-[0.85] group-hover/gallery:brightness-100 transition-all duration-1000" 
              />
            </div>
          ))}
        </div>

        {/* Zoom Indicator Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/gallery:opacity-100 transition-opacity bg-black/20 backdrop-blur-[2px] z-10 pointer-events-none">
          <div className="bg-white/20 p-4 rounded-full border border-white/40 shadow-2xl">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7" />
            </svg>
          </div>
        </div>
        
        {/* Navigation Arrows */}
        <div className="absolute inset-0 flex items-center justify-between px-4 z-20 pointer-events-none opacity-0 group-hover/gallery:opacity-100 transition-opacity">
          <button 
            onClick={(e) => { e.stopPropagation(); prevImage(); }}
            aria-label="আগের ছবি"
            className="w-12 h-12 rounded-full bg-black/30 text-white flex items-center justify-center backdrop-blur-md pointer-events-auto hover:bg-yellow-400 hover:text-[#003366] focus:bg-yellow-400 focus:text-[#003366] transition-all outline-none"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7" /></svg>
          </button>
          <button 
            onClick={(e) => { e.stopPropagation(); nextImage(); }}
            aria-label="পরের ছবি"
            className="w-12 h-12 rounded-full bg-black/30 text-white flex items-center justify-center backdrop-blur-md pointer-events-auto hover:bg-yellow-400 hover:text-[#003366] focus:bg-yellow-400 focus:text-[#003366] transition-all outline-none"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7" /></svg>
          </button>
        </div>

        {/* Badges */}
        <div className="absolute top-6 left-6 flex flex-wrap gap-2 z-30">
          <div className="bg-[#003366] text-white text-[10px] font-black px-4 py-2 rounded-xl uppercase tracking-widest border border-white/10">{product.brand}</div>
          <div className="bg-yellow-400 text-[#003366] text-[10px] font-black px-4 py-2 rounded-xl uppercase tracking-widest">{product.category === 'Rod' ? 'রড' : 'সিমেন্ট'}</div>
        </div>

        <button
          onClick={(e) => { e.stopPropagation(); onCompareToggle(product); }}
          aria-label={isCompared ? "তুলনা থেকে সরান" : "তুলনার জন্য যোগ করুন"}
          className={`absolute top-6 right-6 z-30 p-3 rounded-xl backdrop-blur-md transition-all border outline-none ${
            isCompared ? 'bg-yellow-400 text-[#003366] border-yellow-300 scale-110' : 'bg-black/20 text-white border-white/10 hover:bg-white/20 focus:bg-white/30'
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
          </svg>
        </button>
      </div>

      {/* Lightbox */}
      {isLightboxOpen && (
        <div 
          className="fixed inset-0 z-[100] flex flex-col bg-black/98 backdrop-blur-3xl animate-fadeInFast select-none"
          role="dialog"
          aria-modal="true"
          aria-label="Image lightbox"
        >
          {/* Top Control Bar */}
          <div className="absolute top-0 inset-x-0 h-24 px-8 flex items-center justify-between bg-gradient-to-b from-black/80 to-transparent z-[120]">
            <div className="flex items-center gap-6">
              <span className="text-white/60 font-black tracking-widest text-xs uppercase">মজবুত নির্মাণ সামগ্রী</span>
              <div className="h-6 w-[1px] bg-white/20"></div>
              <span className="text-white font-bold">{lightboxIdx + 1} / {product.productImages.length}</span>
            </div>
            <div className="flex items-center gap-4">
              <button 
                onClick={(e) => { e.stopPropagation(); setPanPos({x: 50, y: 50}); setIsZoomed(!isZoomed); }}
                aria-label={isZoomed ? "জুম আউট" : "জুম ইন"}
                className={`p-4 rounded-full transition-all focus:outline-none focus:ring-2 focus:ring-yellow-400 ${isZoomed ? 'bg-yellow-400 text-[#003366]' : 'bg-white/10 text-white hover:bg-white/20'}`}
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  {isZoomed ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM13 10H7" /> : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7" />}
                </svg>
              </button>
              <button 
                onClick={closeLightbox} 
                aria-label="বন্ধ করুন"
                className="p-4 bg-red-500 text-white rounded-full hover:bg-red-600 focus:ring-2 focus:ring-white transition-all outline-none"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
          </div>

          {/* Main Content */}
          <div 
            ref={containerRef}
            className={`relative flex-grow flex items-center justify-center overflow-hidden transition-all duration-300 ${isZoomed ? 'cursor-zoom-out' : 'cursor-zoom-in'}`}
            onMouseMove={handleMouseMove}
            onClick={toggleZoom}
          >
            <div 
              className="relative w-full h-full flex items-center justify-center transition-transform duration-500 ease-out"
              style={{ 
                transform: isZoomed ? `scale(3)` : 'scale(1)', 
                transformOrigin: isZoomed ? `${panPos.x}% ${panPos.y}%` : 'center center' 
              }}
            >
              <img 
                src={product.productImages[lightboxIdx]} 
                alt={`${product.name} ভিউ ${lightboxIdx + 1}`} 
                className="max-w-[90%] max-h-[85%] object-contain rounded-lg shadow-[0_0_100px_rgba(0,0,0,0.5)]"
                draggable={false} 
              />
            </div>
          </div>

          {/* Bottom Thumbnails */}
          <div className="h-32 bg-black/40 backdrop-blur-md flex items-center justify-center gap-4 px-8 z-[110] overflow-x-auto no-scrollbar">
            {product.productImages.map((img, idx) => (
              <button 
                key={idx}
                onClick={(e) => { e.stopPropagation(); setLightboxIdx(idx); setIsZoomed(false); }}
                aria-label={`ছবি ${idx + 1} দেখুন`}
                className={`w-20 h-20 rounded-xl overflow-hidden border-4 transition-all shrink-0 focus:outline-none focus:ring-2 focus:ring-yellow-400 ${lightboxIdx === idx ? 'border-yellow-400 scale-110' : 'border-white/10 opacity-50 hover:opacity-100'}`}
              >
                <img src={img} className="w-full h-full object-cover" alt={`থাম্বনেইল ${idx + 1}`} />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Card Content Section */}
      <div className="p-6 md:p-8 flex flex-col flex-grow">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 mb-4">
          <h3 className="text-xl md:text-2xl font-black text-[#003366] leading-tight group-hover:text-blue-700 transition-colors">
            {product.name}
          </h3>
          <div className="flex items-center gap-2">
            {renderStars(Number(averageRating))}
            <span className="text-sm font-bold text-gray-400" aria-label={`${reviews.length} reviews`}>({reviews.length})</span>
          </div>
        </div>
        
        <div className="overflow-y-auto max-h-24 pr-2 mb-6 text-gray-600 leading-relaxed text-sm md:text-base font-medium italic">
          "{product.description}"
        </div>

        <div className="mb-6 flex-grow">
          <div className="flex items-center justify-between mb-4 border-b border-gray-100 pb-2">
            <h4 className="text-[10px] font-black text-[#003366] uppercase tracking-[0.2em]">গ্রাহক মতামত</h4>
            <button 
              onClick={() => setShowReviewForm(!showReviewForm)} 
              aria-expanded={showReviewForm}
              className="text-xs font-bold text-blue-600 hover:text-blue-800 focus:underline outline-none"
            >
              {showReviewForm ? 'বন্ধ করুন' : 'মতামত দিন'}
            </button>
          </div>

          {showReviewForm ? (
            <form onSubmit={handleReviewSubmit} className="bg-gray-50 p-4 rounded-2xl space-y-3">
              <input 
                type="text" 
                placeholder="আপনার নাম" 
                aria-label="নাম"
                value={newReview.userName} 
                onChange={(e) => setNewReview({ ...newReview, userName: e.target.value })} 
                className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-yellow-400 outline-none" 
                required 
              />
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-bold text-gray-500">রেটিং:</span>
                {renderStars(newReview.rating, true)}
              </div>
              <textarea 
                placeholder="মতামত..." 
                aria-label="মতামত"
                value={newReview.comment} 
                onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })} 
                className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-yellow-400 outline-none h-16 resize-none" 
                required 
              />
              <button 
                type="submit" 
                disabled={isSubmitting} 
                className="w-full bg-[#003366] text-white font-bold py-2 rounded-xl text-sm hover:bg-blue-800 transition-colors focus:ring-2 focus:ring-yellow-400 outline-none"
              >
                {isSubmitting ? 'পাঠানো হচ্ছে...' : 'জমা দিন'}
              </button>
            </form>
          ) : (
            <div className="space-y-4 max-h-40 overflow-y-auto pr-2 custom-scrollbar">
              {reviews.length > 0 ? reviews.map(review => (
                <div key={review.id} className="bg-gray-50/50 p-3 rounded-xl border border-gray-100">
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-xs font-bold text-[#003366]">{review.userName}</span>
                    <span className="text-[10px] text-gray-400">{review.date}</span>
                  </div>
                  {renderStars(review.rating)}
                  <p className="text-xs text-gray-600 mt-2 font-medium">"{review.comment}"</p>
                </div>
              )) : (
                <p className="text-xs text-gray-400 italic text-center py-4">এখনো কোনো মতামত নেই।</p>
              )}
            </div>
          )}
        </div>

        <div className="mt-auto pt-6 border-t border-gray-100 flex flex-col gap-6">
          <a href="#contact" className="group/btn w-full relative inline-flex items-center justify-center gap-3 bg-[#003366] text-white px-8 py-5 rounded-2xl font-bold text-lg hover:bg-blue-800 transition-all shadow-xl active:scale-[0.98] focus:ring-4 focus:ring-blue-200 outline-none">
            <span>দরদাম জানুন</span>
            <svg className="w-6 h-6 group-hover/btn:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
