
import React, { useState, useEffect, useCallback } from 'react';
import { TESTIMONIALS } from '../constants.tsx';

const Testimonials: React.FC = () => {
  const [activeIdx, setActiveIdx] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  const nextSlide = useCallback(() => {
    setActiveIdx((prev) => (prev + 1) % TESTIMONIALS.length);
  }, []);

  const prevSlide = useCallback(() => {
    setActiveIdx((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  }, []);

  useEffect(() => {
    if (isHovered) return;
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, [isHovered, nextSlide]);

  return (
    <section className="py-32 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-24">
          <h2 className="text-4xl md:text-6xl font-black text-[#003366] mb-6">আমাদের ওপর যারা <span className="text-blue-600">ভরসা রাখেন</span></h2>
          <div className="w-32 h-2 bg-yellow-400 mx-auto rounded-full mb-10"></div>
        </div>

        <div 
          className="relative max-w-5xl mx-auto"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {/* Enhanced Carousel */}
          <div className="overflow-hidden">
            <div 
              className="flex transition-all duration-[1200ms] ease-[cubic-bezier(0.4, 0, 0.2, 1)]"
              style={{ transform: `translateX(-${activeIdx * 100}%)` }}
            >
              {TESTIMONIALS.map((item) => (
                <div key={item.id} className="min-w-full px-4">
                  <div className="bg-slate-50 border border-slate-100 p-12 md:p-20 rounded-[4rem] relative shadow-3xl flex flex-col items-center text-center group">
                    <div className="absolute top-10 left-10 text-9xl text-blue-200/40 font-serif leading-none">“</div>
                    
                    <div className="relative z-10 mb-10">
                      <div className="w-28 h-28 md:w-40 md:h-40 rounded-[3rem] overflow-hidden border-8 border-white shadow-2xl transition-transform group-hover:scale-105 duration-500">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                    </div>

                    <p className="text-2xl md:text-4xl text-slate-700 italic font-medium leading-tight mb-12 max-w-3xl animate__animated animate__fadeIn">
                      {item.content}
                    </p>

                    <div className="mb-4 flex gap-2">
                       {[...Array(5)].map((_, i) => (
                         <svg key={i} className="w-6 h-6 text-yellow-400 fill-current" viewBox="0 0 20 20">
                           <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                         </svg>
                       ))}
                    </div>

                    <h4 className="text-3xl font-black text-[#003366]">{item.name}</h4>
                    <p className="text-blue-600 font-bold uppercase tracking-widest text-sm mt-2">{item.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Luxury Controls */}
          <div className="hidden md:block">
            <button onClick={prevSlide} className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-20 h-20 bg-white shadow-2xl rounded-full flex items-center justify-center text-blue-900 hover:bg-yellow-400 transition-all z-20 border border-slate-100 group">
              <svg className="w-8 h-8 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <button onClick={nextSlide} className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-20 h-20 bg-white shadow-2xl rounded-full flex items-center justify-center text-blue-900 hover:bg-yellow-400 transition-all z-20 border border-slate-100 group">
              <svg className="w-8 h-8 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>

          <div className="flex justify-center gap-4 mt-12">
            {TESTIMONIALS.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveIdx(i)}
                className={`h-3 rounded-full transition-all duration-700 ${
                  activeIdx === i ? 'w-16 bg-[#003366]' : 'w-4 bg-slate-200 hover:bg-slate-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
